<?php

namespace Database\Factories;

use App\Models\IncidenceDocuments;
use Illuminate\Database\Eloquent\Factories\Factory;

class IncidenceDocumentsFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = IncidenceDocuments::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
